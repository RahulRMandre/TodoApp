package com.example.todoapp.data.repository

import androidx.annotation.WorkerThread
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.todoapp.data.dao.AllTaskTitleDao
import com.example.todoapp.data.dao.TaskDao
import com.example.todoapp.data.dao.UserDao
import com.example.todoapp.data.model.AllTaskTitles
import com.example.todoapp.data.model.Task
import com.example.todoapp.data.model.TimeStatus
import com.example.todoapp.data.model.TitleType
import kotlinx.coroutines.flow.Flow


class TaskRepository(
    private val taskDao: TaskDao,
    private val userDao: UserDao,
    private val allTaskTitleDao: AllTaskTitleDao
) {
    val allTaskTitlesList: Flow<List<AllTaskTitles>> = allTaskTitleDao.getAllTaskTitles()

    @Suppress("RedundantSuspendModifier")
    @WorkerThread
    suspend fun insert(allTaskTitles: AllTaskTitles) {
        allTaskTitleDao.insert(allTaskTitles)
    }


}