package com.example.todoapp.data

import androidx.lifecycle.MutableLiveData
import com.example.todoapp.data.database.TaskRoomDatabase
import com.example.todoapp.data.model.AllTaskTitles

