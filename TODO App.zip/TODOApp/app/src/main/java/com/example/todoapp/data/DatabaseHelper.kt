package com.example.todoapp.data

import androidx.lifecycle.MutableLiveData
import com.example.todoapp.data.model.AllTaskTitles

interface DatabaseHelper {
    suspend fun getAllTaskList():MutableLiveData<ArrayList<AllTaskTitles>>
    suspend fun  addAllTaskList(allTaskTitles: AllTaskTitles):Unit


}