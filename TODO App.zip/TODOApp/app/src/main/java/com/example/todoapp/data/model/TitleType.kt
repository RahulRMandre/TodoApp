package com.example.todoapp.data.model

enum class TitleType {
    DEFAULT,
    CUSTOM
}
