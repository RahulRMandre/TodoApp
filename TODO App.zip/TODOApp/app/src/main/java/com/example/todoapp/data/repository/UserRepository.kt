package com.example.todoapp.data.repository

import com.example.todoapp.data.model.User

class UserRepository {

    fun getUser()= User(name="Rahul Mandre",email = "rahul.r.mandre@outlook.com")


}